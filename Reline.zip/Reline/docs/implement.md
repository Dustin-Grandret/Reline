在不讲求功能的具体实现的情况下将尽可能多的函数规划出来。

定理:
1. Model的派生类可以不实现任何东西
2. View的派生类必须实现_createDom,_render,_constructor
3. SubModel的派生类必须实现_getAttribPairs
4. Entity用来存放很多数据项
5. 将Entity,Relation公称为Concept
6. Concept需要拥有basic,style
7. 所有的类的构造函数都必须返回对象本身,使用构造函数说明类的结构

> **MANAGE:** entity.txt
Entity:
    constructor();


> **FILE:** entity.js
```javascript
class Entity extends Model{
    constructor(){
        super();
        /**
         * this.basic存储基本属性，基本属性在创建后不变，且基本属性的值与类型
         * 唯一确定一个对象
         */
        this.basic={};
        /**
         * this.style存储对象的外观属性,this.style应唯一确定一个对象的表现形式,
         * this.style包含Renderer对象
         * @type {{}}
         */
        this.style={};
        /**
         * this.content存储对象的内容属性,这个内容属性可以修改，或添加其他的内容属性
         * 一般来说this.content需要由value属性
         * @type {{}}
         */
        this.content={};
        /**
         * this.external存储对象的外部属性(如实体的外部属性由关系)，以对象的形式存储
         * @type {{}}
         */
        this.external={};
        return this;
    }
}
```

> **FILE:** entity.test.js
```javascript
function test_Entity_set(arg){
    var e1=new Entity();
    e1.set(
        [{
        attribute:'basic.id',
        value:'123d'
        },{
            attribute:'style.width',
            value:100
        }]
    )
    return e1.basic.id==='123d'&&e1.style.width===100;
}
function addTestFuntcions(testFunction){
    testFunction.push(test_Entity_set,'Entity 的set实现有问题');
}
```

> **FILE:** relation.js
```javascript
class Relation extends SubModel{
    constructor(){
        super();
        /**
         * this.basic存储基本属性，基本属性在创建后不变，且基本属性的值与类型
         * 唯一确定一个对象
         */
        this.basic={};
        /**
         * this.style存储对象的外观属性,this.style应唯一确定一个对象的表现形式,
         * this.style包含Renderer对象
         * @type {{}}
         */
        this.style={};
        /**
         * this.content存储对象的内容属性,这个内容属性可以修改，或添加其他的内容属性
         * 一般来说this.content需要由value属性
         * @type {{}}
         */
        this.content={};
        /**
         * this.external存储对象的外部属性(如实体的外部属性由关系)，以对象的形式存储
         * @type {{}}
         */
        this.external={};
        return this;
    }

    /**
     * 根据this.model获取对应值进行更新
     * @private
     */
    _getAttribPairs() {
        return [
            {attribute:'style.points',value:getPoints(this.models)}
        ];
    }
}
```

> **FILE:** relation.test.js
```javascript
function test_Relation_set(arg){
    
}
function test_getPoints(arg){

}
function addTestFuntcions(testFunction){
    testFunction.push(test_Relation_set,'...');
}
```

> **FILE:** entity_relation.test.js
```javascript
    function test_Entity_addObserver(arg){
        //entity和Relation都要测试
    }
    function test_Relation_update(arg){

    }
    function addTestFuntcions(testFunction){
        testFunction.push(test_Relation_update,'...');
    }

```

> **FILE:** entityRenderer.js
```javascript
class EntityRenderer extends View{
    constructor(arg){
        super();
    }

    /**
     * 完成如何获取外部变量(如自己的上级元素)
     * 
     */
    _constructor(arg){
        
    }
    _createDom(arg){
        //this.dom.append(createSvgElement())
    }
    _render() {
        //搜索
        //this.dom.
        //从this.model中拿数据并赋值
    }
}
```
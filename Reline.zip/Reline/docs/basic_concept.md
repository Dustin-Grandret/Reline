这是Reline的基本概念整理

对于一个渲染类,应该有
+ 渲染类名
+ 渲染类的本征css伪类

Rd开头的类为渲染类。

RdNormal:
+ 色块 entityBlock
  + 字 contextBlock

    

    entity(entityBlock+contextBlock(foreignBlock+text))

最终我们确定程序将会以这种方式构建：
Model维护一个observer列表，在每次更新时调用该列表,该列表上的元素逐一调用
自己的更新方法**重新渲染所有dom节点**。所以Model到View总是拓扑结构。
对于View上的更新方法，我们要求其事件总是与Model相连。

```javascript
"use strict"

class Model{
  /**
   * Model类所代表的是有多个观察者的对象
   * @constructor
   * @returns {Model}
   */
  constructor(){
    this.observers=[];
    return this;
  }

  /**
   * 添加观察者元素,同时给观察者元素添加自身的引用
   * @param {Object} arg.observer 作为Model的观察者的一个View类
   */
  addObserver(arg){
    this.observers.push(arg.observer);
    //区分observer为SubModel还是View
    (arg.observer.addModel||arg.observer.setModel)(this);
  }

  /**
   * 在Model类做出改变后通知所有的观察者进行更新
   */
  update(){
    this.observers.forEach((view)=>{
      view.update(this);
    });
  }

  /**
   * 设置模型的诸多属性同时通知观察者更新
   * @param pairs{Array} pair组成的属性。
   * @param pairs[].attribute{String} pair中的元素。以逗号分割,可以取更深层的元素进行赋值
   * @param pairs[].value pair中的元素。某变量的新值
   */
  set(pairs){
    //...
    pairs.forEach((pair)=>{this._set(pair.attribute.split('.'),pair.value)});
    this.update();
  }

  /**
   * 对对象的深层变量赋值
   * @param attributes{Array} 变量,第i个下标所指向的元素有以第i+1个下标所指向的元素为名的属性
   * @param value 某变量的新值
   * @private
   */
  _set(attributes,value){
    let tran = this;
    for(let i=0;i<attributes.length-1;++i){
      tran=tran[attributes[i]];
    }
    tran[attributes[attributes.length-1]]=value;
  }
}
class View{
  /**
   * View类所代表的没有观察者的被动更新的对象,View类要完成对页面进行渲染的工作
   * dom在初始始为null,在第一次this.render()时被赋值。
   * 规定View对应于一个model
   * @returns {View}
   */
  constructor(){
    this.dom=null;
    this.model=null;
    this._constructor();
    return this;
  }

  /**
   * 设置自身所对应的唯一Model类
   * @param arg.model {Model}
   */

  setModel(arg){
    this.model=arg.model;
  }

  /**
   * 如果dom树没有被创建则要被创建,如果已经被创建了则要根据Model对象进行重新渲染
   * @param model
   * @returns {View}
   */
  update(model){
    if(this.dom===null) {
      this._createDom();
    }
    this._render();
    return this;
  }

  /**
   * 导入外部环境变量(如dom树应出于的环境)
   * 派生类应完成的工作:导入外部变量
   * @private
   */
  _constructor(){

  }
  /**
   * 在dom树没有被创建的情况下创建dom树,由派生类编写.注意外部环境变量由this导入
   * 派生类应完成的工作:创建dom树
   * @private
   */
  _createDom(){

  }

  /**
   * 将dom树上的所有属性更新
   * 派生类应完成的工作:通过this.model完成更新
   * @private
   */
  _render(){

  }
}
class SubModel extends Model{
  /**
   * SubModel 作为其他Model类的观察者的同时也有Model类的接口
   * 规定SubModel类的model属性可以有多个元素.
   * @example
   * Relation作为Entity的观察者的同时也有观察者
   * @constructor
   * @returns {Model}
   */
  constructor(){
    super();
    this.model=[];
    return this;//readable
  }

  /**
   * 添加自身所对应的Model类
   * @param arg.model{Model}
   */
  addModel(arg){
    this.model.push(arg.model);
  }
  /**
   * 如果dom树没有被创建则要被创建,如果已经被创建了则要根据Model对象进行重新渲染
   * @param model
   * @returns {Model}
   */
  update(model){
    this.set(this._getAttribPairs());
    return this;
  }
  _getAttribPairs(){

  }
}
```

```javascript
/*
* 写一个简单的例子给小黄鸭解释流程
* 例子1:
* entity1:Model;
* entity2:Model;
* relation:SubModel;
* entity1Renderer:View;
* entity2Renderer:View;
* relationRenderer:View;
* 其中上述都是已经实例化的变量,entity1和entity2作为Model类有relation
* 作为其SubModel,entity1,entity2,relation都分别有一个在svg画布上的
* 一个映射
* */

//初始化
var entity1=new Model();
var entity2=new Model();
var relation=new SubModel();

var entity1Renderer=new View();
var entity2Renderer=new View();
var relationRenderer=new View();
//绑定
entity1.addObserver({arg:relation});
entity1.addObserver({arg:entity1Renderer});

entity2.addObserver({arg:relation});
entity2.addObserver({arg:entity2Renderer});

relation.addObserver({arg:relationRenderer});
//赋值
entity1.set([{},{},{}]);
entity2.set([{},{},{}]);
entity1.set([{},{},{}]);
```

接下来的开发应该对应6个测试

EntityNormal类的开发---测试项:
1. EntityNormal.set()
2. 写出在开发Entity类时都做了哪些工作

---
EntityNormalRenderer---测试项:
  1. Entity在Svg元素上显示
  2. 当Entity变化时Svg上的元素可以变化
  3. EntityNormalRenderer.addEventListener()
  4. 写出在开发EntityNormalRenderer时都做了哪些工作
  
---

RelationNormal类的开发
1. 首先根据开发EntityNormal时所定义的工作思考构建RelationNormal需要哪些工作
2. 测试手动更改Relation是否有效
3. 测试在EntityNormal更改时是否RelationNormal会更改

---
完成对RelationNormalRenderer的开发

---
完成对Entity,Relation的HTML组件的开发

---
---
EntityNormal developing:
1.write the test code.

- [ ] 构建出Center,Edge
- [ ] 搬运Entity,测试
- [ ] 搬运Relation,测试
- [ ] 搬运Diagram,测试
- [ ] 序列化状态
- [ ] 反序列化状态
- [ ] 完成诸多功能

我希望以如下方式画出一个矩形
```javascript
var rect=new Entity([createRect()]);
```
并且，当我改动这个rect对象时，这个矩形他会被自动更改
```javascript
rect.update('x',5);
```

Reline开发理念

1. 雪花模型(n对1)
2. 载入载出时使用对象池
```javascript
"use strict"
class Center{    
    construction{
        this.id='';
    }
    function addEdge(elem){
        this.observeList.push({id:elem.id,type:elem.type})
    }
    function update(attribute,value){
        this.observeList.forEach((elem)=>{
            elem.update(attribute,value,this.id);
        })
    }
}
class Edge{
    function setCenter(elem){
        this.center=elem;
    }
    function update(attribute,value){
		//进行更改操作
		if(source is not in this.center.ids){
			this.center.update(attribute,value);
		}
    }
}

```
2021/10/29

我的目标是要将12张思维导图画出来。

什么叫"将思维导图画出来"

用户可以使用我的这款软件将思维导图绘制在软件的画布上

用户如何使用我这款软件绘制思维导图在画布上?

用户通知drawer进行绘制，drawer统一管理所有的entity和relations,drawer通知entity和relations改变内容
entity和relations在改变内容的同时改变相关联的ui
entity改变时改变relations:
	Center需要有一个id
	
RdEntity如何渲染Entity?
创建RdEntity时就已经把dom构建出来。
在Entity加载内容时将dom的属性构建出来
	Entity(RdEntity);
	Entity.translate(...);
	
也就是说绑定应该在赋值之后
1.创建空元素
2.绑定
3.赋值

```javascript
var e1=new Entity();
var e2=new Entity();
var r1=new Relatation();

e1.bind(r1);
e2.bind(r1);

e1.translate(...)
```

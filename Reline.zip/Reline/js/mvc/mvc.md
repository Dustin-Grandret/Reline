Reline所实现的MVC架构与正常的架构稍有不同

核心是类似于雪花

[雪花图片]

雪花分为边缘和中心，利用观察者模式使得当一个对象的内容被更新时，所有关联对象的内容都被更新。

第二个是数据劫持，对于一个对象的更改(比如移动一个对象，更改该对象的x，y值)。通过控制器进行更改。

控制器对外提供更改的接口但实际上的操作是向雪花中心发送更改请求。


雪花模式核心在于
1. 设置Center让消息传递与控制业务逻辑的类解耦
2. 利用Edge->Center->Edge实现消息传递
3. 利用并查集保证无环
4. 首先让Entity继承Edge类，然后重写_update方法,在每一个可能改变Edge类的地方使用update而非=(assign operator)
```javascript
class Center extends UnionNode{    
    constructor(arg){
	   super();
       this.observeList=new Array();
	   this.head=this;
    }
    addEdge(arg){
		this.observeList.push(arg.edge);
    }
	/**
	 * @description 通过Center.update来传递消息
	 * @param {EdgeOrSystem} arg.source  本次迭代中消息传递的源头
	 * @param {string} arg.attribute 所要更新的参数
	 * @param {string} arg.value 所要更新的值  
	 */
    update(arg){
        this.observeList.forEach((elem)=>{
			if(arg.source!=elem){
				elem.update({attribute:arg.attribute,value:arg.value,source:this});
			}
        })
    }
	/**
	 * Center类链接Edge类,arg={edge:}
	 * @param {Object} arg.edge 
	 */
	bind(arg){
		if(!this.sameRoot(arg.edge)){
			this.Unite(arg.edge);
			this.addEdge({edge:arg.edge});
			arg.edge.setCenter({center:this});
		}
	}
}
class Edge extends UnionNode{
	constructor(arg) {
	   super();
	   this.centers=new Array();
	}
    setCenter(arg){
        this.centers.push(arg.center);
    }
	/**
	 * 这个函数在被继承时通常要改变
	 * @param {Object} arg
	 */
	_update(arg){
		this[arg.attribute]=arg.value;
	}
	/**
	 * @param {Object} arg.attribute
	 * @param {Object} arg.value
	 * @param {Object} arg.source ['system']-来源,默认为system
	 */
    update(arg){
		this._update(arg);
		this.centers.forEach((center)=>{
			if(center!=(arg.source||'system')){
				center.update({attribute:arg.attribute,value:arg.value,source:this});
			}
		})
    }
}
```
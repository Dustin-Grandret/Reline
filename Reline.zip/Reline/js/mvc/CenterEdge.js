class UnionNode{
    constructor(arg) {
        this.parentNode=this;
    }
    /**
     * 寻找根节点
     */
    findUnionRoot(){
        if(this.parentNode===this){//根节点
            return this;
        }else{
            return this.parentNode.findUnionRoot();
        }
    }
    /**
     * 将a与b合并，将a的根节点指向b
     * @param {Object} a
     * @param {Object} b
     */
    Unite(b){
        this.findUnionRoot().parentNode=b.findUnionRoot();
    }
    sameRoot(b){
        return this.findUnionRoot()===b.findUnionRoot();
    }
}
class Center extends UnionNode{
    /**
     * @description 雪花类的中心，雪花类和Edge类要解决的一个问题是循环调用造成死锁。
     * @description 所以实现为并查集
     */
    constructor(arg){
        super();
        this.observeList=new Array();
        this.head=this;
    }
    addEdge(arg){
        this.observeList.push(arg.edge);
    }
    /**
     * @description 通过Center.update来传递消息
     * @param {EdgeOrSystem} arg.source  本次迭代中消息传递的源头
     * @param {string} arg.attribute 所要更新的参数
     * @param {string} arg.value 所要更新的值
     */
    update(arg){
        this.observeList.forEach((elem)=>{
            if(arg.source!=elem){
                elem.update({attribute:arg.attribute,value:arg.value,source:this});
            }
        })
    }
    /**
     * Center类链接Edge类,arg={edge:}
     * @param {Object} arg.edge
     */
    bind(arg){
        if(!this.sameRoot(arg.edge)){
            this.Unite(arg.edge);
            this.addEdge({edge:arg.edge});
            arg.edge.setCenter({center:this});
        }
    }
}
class Edge extends UnionNode{
    constructor(arg) {
        super();
        this.centers=new Array();
    }
    setCenter(arg){
        this.centers.push(arg.center);
    }
    /**
     * 这个函数在被继承时通常要改变
     * @param {Object} arg
     */
    _update(arg){
        this[arg.attribute]=arg.value;
    }
    /**
     * @param {Object} arg.attribute
     * @param {Object} arg.value
     * @param {Object} arg.source ['system']-来源,默认为system
     */
    update(arg){
        this._update(arg);
        this.centers.forEach((center)=>{
            if(center!==(arg.source||'system')){
                center.update({attribute:arg.attribute,value:arg.value,source:this});
            }
        })
    }
}

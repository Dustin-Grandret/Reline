"use strict"

/**
 * @example
 * //初始化
 * var entity1=new Model();
 * var entity2=new Model();
 * var relation=new SubModel();
 *
 * var entity1Renderer=new View();
 * var entity2Renderer=new View();
 * var relationRenderer=new View();
 * //绑定
 * entity1.addObserver({arg:relation});
 * entity1.addObserver({arg:entity1Renderer});
 *
 * entity2.addObserver({arg:relation});
 * entity2.addObserver({arg:entity2Renderer});
 *
 * relation.addObserver({arg:relationRenderer});
 * //赋值
 * entity1.set([{},{},{}]);
 * entity2.set([{},{},{}]);
 * entity1.set([{},{},{}]);
 */
class Model{
	/**
	 * Model类所代表的是有多个观察者的对象
	 * @constructor
	 * @returns {Model}
	 */
	constructor(){
		this.observers=[];
		return this;
	}

	/**
	 * 添加观察者元素,同时给观察者元素添加自身的引用
	 * @param {Object} arg.observer 作为Model的观察者的一个View类
	 */
	addObserver(arg){
		this.observers.push(arg.observer);
		//区分observer为SubModel还是View
		(arg.observer.addModel||arg.observer.setModel)(this);
	}

	/**
	 * 在Model类做出改变后通知所有的观察者进行更新
	 */
	update(){
		this.observers.forEach((view)=>{
			view.update(this);
		});
	}

	/**
	 * 设置模型的诸多属性同时通知观察者更新
	 * @param pairs{Array} pair组成的属性。
	 * @param pairs[].attribute{String} pair中的元素。以逗号分割,可以取更深层的元素进行赋值
	 * @param pairs[].value pair中的元素。某变量的新值
	 */
	set(pairs){
		//...
		pairs.forEach((pair)=>{this._set(pair.attribute.split('.'),pair.value)});
		this.update();
	}

	/**
	 * 对对象的深层变量赋值
	 * @param attributes{Array} 变量,第i个下标所指向的元素有以第i+1个下标所指向的元素为名的属性
	 * @param value 某变量的新值
	 * @private
	 */
	_set(attributes,value){
		let tran = this;
		for(let i=0;i<attributes.length-1;++i){
			tran=tran[attributes[i]];
		}
		tran[attributes[attributes.length-1]]=value;
	}
}
class View{
	/**
	 * View类所代表的没有观察者的被动更新的对象,View类要完成对页面进行渲染的工作
	 * dom在初始始为null,在第一次this.render()时被赋值。
	 * 规定View对应于一个model
	 * @returns {View}
	 */
	constructor(){
		this.dom=null;
		this.model=null;
		this._constructor();
		return this;
	}

	/**
	 * 设置自身所对应的唯一Model类
	 * @param arg.model {Model}
	 */

	setModel(arg){
		this.model=arg.model;
	}

	/**
	 * 如果dom树没有被创建则要被创建,如果已经被创建了则要根据Model对象进行重新渲染
	 * @param model
	 * @returns {View}
	 */
	update(model){
		if(this.dom===null) {
			this._createDom();
		}
		this._render();
		return this;
	}

	/**
	 * 导入外部环境变量(如dom树应出于的环境)
	 * 派生类应完成的工作:导入外部变量
	 * @private
	 */
	_constructor(){

	}
	/**
	 * 在dom树没有被创建的情况下创建dom树,由派生类编写.注意外部环境变量由this导入
	 * 派生类应完成的工作:创建dom树
	 * @private
	 */
	_createDom(){

	}

	/**
	 * 将dom树上的所有属性更新
	 * 派生类应完成的工作:通过this.model完成更新
	 * @private
	 */
	_render(){

	}
}
class SubModel extends Model{
	/**
	 * SubModel 作为其他Model类的观察者的同时也有Model类的接口
	 * 规定SubModel类的model属性可以有多个元素.
	 * @example
	 * Relation作为Entity的观察者的同时也有观察者
	 * @constructor
	 * @returns {Model}
	 */
	constructor(){
		super();
		this.model=[];
		return this;//readable
	}

	/**
	 * 添加自身所对应的Model类
	 * @param arg.model{Model}
	 */
	addModel(arg){
		this.model.push(arg.model);
	}
	/**
	 * 如果dom树没有被创建则要被创建,如果已经被创建了则要根据Model对象进行重新渲染
	 * @param model
	 * @returns {Model}
	 */
	update(model){
		this.set(this._getAttribPairs());
		return this;
	}
	_getAttribPairs(){

	}
}

"use strict"

/*
这个文件存放整个页面的启动程序
1.加载配置项
2.生成UI
3.绑定UI
4.加载svg元素
*/
function __a1(svg) {
    svg.addEventListener('mousedown', (event) => {
        console.log(event.pageX, event.pageY);
        var point = svg.createSVGPoint();
        point.x = event.pageX;
        point.y = event.pageY
        console.log(screenPoint2SvgPoint({svg: svg, point: point}))
        var rect = document.getElementById("123");
        console.log(rect.getScreenCTM());
    })
}

function __a2() {
    var c1 = new Center({id: 1});
    var c2 = new Center({id: 5});
    var e1 = new Edge({id: 2});
    var e2 = new Edge({id: 3});
    var e3 = new Edge({id: 6});
    c1.bind({edge: e1});
    c1.bind({edge: e2});
    c2.bind({edge: e2});
    c2.bind({edge: e3});
    e2.update({attribute: 'x', value: 1, source: 'system'});
    console.log(e2);//output:Edge {...}
    console.log(e1['x'], e2['x'], e3['x']);//output:1 1 1
}

class RunDebug {
    constructor(arg) {
        this.assertions = [];
    }

    /**
     * 添加断言,
     * @param {Function}arg.decision 断言的判断,优先度:0
     * @param {String}arg.log 如果断言失败则输出的错误结果
     * @param {Function} arg.question 某个习题,要求返回一个结果。等效于断言()=>{return arg.question()===arg.answer}
     * @param arg.answer arg.question的答案
     */
    addAssertion(arg) {
        let assertion = {};

        assertion.decision = arg.decision || ((elem) => {
            return arg.question() === arg.answer;
        })

        assertion.log = arg.log || 'ERROR';
        this.assertions.push(assertion);
    }

    /**
     * 创建一个对应错误信息的dom元素
     * @param log
     * @returns {HTMLDivElement}
     */
    bugLog(log) {
        let bugLog = document.createElement('div');
        bugLog.setAttribute('class', 'bug-log');
        bugLog.innerText = log;
        return bugLog;
    }

    run() {
        let start = new Date();
        let debugBlock = document.getElementById('debug');
        let bugNum = 0;
        this.assertions.forEach((assertion) => {
            if (!(assertion.decision())) {
                debugBlock.appendChild(this.bugLog(assertion.log));
                ++bugNum;
            }
        })
        let end = new Date()
        debugBlock.appendChild(this.bugLog('Bug:' + bugNum + '/' + this.assertions.length + ' in' + ' ' + (end - start) + 'ms'));
    }
}
function a3(){
    var svg = document.getElementById(svgName);
    initSvg({svg: svg, viewBox: [0, 0, 100, 100]})
    var arg = {
        svg: svg,
        class: 'rectBasic',
        id: "123",
        tag: 'rect',
        attributes: {x: 0, y: 0, width: 10, height: 10, fill: '#ff00ff'},
        children: [{
            class: 'rr',
            id: "456",
            tag: 'circle',
            attributes: {'cx': 5, cy: 5, r: 10, fill: "red", stroke: 'black', 'stroke-width': 2}
        }]
    };
    //__a1(svg)
    drawRectangle(arg);

    //__a2()

    bindUis()
}
function initApp(svgName) {
    let relineDebug =new RunDebug(0);
    for(let i=0;i<1000;++i){
        relineDebug.addAssertion({
            decision:()=>{return 2+2>3},
            log:'error'
        })
        relineDebug.addAssertion({
            decision:()=>{return 2+2<3},
            log:'error with 2+2<3!'
        })
    }
    //relineDebug.run();
}
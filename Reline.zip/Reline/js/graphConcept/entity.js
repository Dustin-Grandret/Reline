"use strict"

/**
 * @description 这是Entity类
 */
function quickFloor(value){
	return value|0;//快速取整。1.5=>1，-1.5=>-1
}
//clip函数返回一个值在一个阈值内的裁剪
function clip(value,minValue,maxValue){
	if(value<minValue){
		return minValue;
	}else{
		if(value>maxValue){
			return maxValue;
		}
	}
	return value;
}
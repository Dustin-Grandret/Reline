//计算当鼠标滚轮滚动时放缩值变化
var minScaler=0.25;
var maxScaler=2;
var scalerInterval=0.1;
function wheelChangeScaler(curScaller,value){
	return clip(curScaller+scalerInterval*value/100,minScaler,maxScaler);//event.deltaY=-100;100
}
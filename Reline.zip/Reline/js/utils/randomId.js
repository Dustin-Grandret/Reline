var randomIdList=[''];
//返回16进制随机数
function randomHex(){
	return Math.floor(Math.random()*16).toString(16);
}
//返回以16进制构成的,不重复的id
function randomId(length=4){
	var id='';
	while(randomIdList.indexOf(id)!=-1){
		for(let i=0;i<length;++i){
			id+=randomHex();
		}	
	}
	randomIdList.push(id);
	return id;
}
//将两列的二维数组转化成points要求的参数为num num,num num...
function pointsToPolylineParameter(values){
	var points='';
	for(let i=0;i<values.length;++i){
		points+=parseFloat(values[i][0]);
		points+=' '
		points+=parseFloat(values[i][1]);
		if(i!=values.length-1){
			points+=','
		}
	}
	return points;
}
//将两列的二维数组转化成polyline
function pointsToPolyline(values){
	var polyline=document.createElementNS("http://www.w3.org/2000/svg","polyline");
	var points=pointsToPolylineParameter(values);
	polyline.setAttribute('points',points);
	return polyline;
}

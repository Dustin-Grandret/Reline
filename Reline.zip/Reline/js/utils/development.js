function print(value){
	console.log(value);
}
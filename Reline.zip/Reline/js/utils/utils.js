
var VERTICAL_0=0;
var VERTICAL_1=1;
var HORIZONTAL_0=2;
var HORIZONTAL_1=3;
var mainDiagram=document.getElementById('mainDiagram');
var svgPosition=mainDiagram.getBoundingClientRect();
/*
var viewBox=mainDiagram.getAttribute('viewBox').split(' ');
for(let i=0;i<viewBox.length;++i){
	viewBox[i]=parseFloat(viewBox[i]);
}
console.log(viewBox);
*/





function BoxLayOut(args){
	/*
	args={
		width
		height
		marginX
		marginY
		count
		columnNum
		originX
		originY
	}
	*/
	return [(args.originX||0)+(args.count%args.columnNum)*(args.width+args.marginX),
		   (args.originY||0)+(quickFloor(args.count/args.columnNum))*(args.height+args.marginY)]
}

//中心连线算法:要求两个方块不重叠
function getTwoBlockGR(entity1Pos,entity2Pos){
	var minX=Math.min(entity1Pos[0],entity2Pos[0]);
	var maxX=Math.max(entity1Pos[0]+entity1Pos[2],entity2Pos[0]+entity2Pos[2]);
	var isVerticalArrange=((maxX-minX)<(entity1Pos[2]+entity2Pos[2]));
	if(isVerticalArrange){
		if(entity1Pos[1]<entity2Pos[1]){
			return VERTICAL_0;
		}else{
			return VERTICAL_1;
		}
	}else{
		if(entity2Pos[0]+entity2Pos[2]<entity1Pos[0]){
			return HORIZONTAL_0;
		}else{
			return HORIZONTAL_1;
		}
	}
}
function getRelationPos(entity1,entity2){
	var entity1Pos=entity1.getCurPos();
	var entity2Pos=entity2.getCurPos();
	
	switch(getTwoBlockGR(entity1Pos,entity2Pos)){
		case(VERTICAL_0):
			return [
				[entity1Pos[0]+entity1Pos[2]/2,entity1Pos[1]+entity1Pos[3]],
				[entity1Pos[0]+entity1Pos[2]/2,(entity1Pos[1]+entity1Pos[3]+entity2Pos[1])/2],
				[entity2Pos[0]+entity2Pos[2]/2,(entity1Pos[1]+entity1Pos[3]+entity2Pos[1])/2],
				[entity2Pos[0]+entity2Pos[2]/2,entity2Pos[1]],
				];
		case(VERTICAL_1):
			return [
				[entity1Pos[0]+entity1Pos[2]/2,entity1Pos[1]],
				[entity1Pos[0]+entity1Pos[2]/2,(entity2Pos[1]+entity2Pos[3]+entity1Pos[1])/2],
				[entity2Pos[0]+entity2Pos[2]/2,(entity2Pos[1]+entity2Pos[3]+entity1Pos[1])/2],
				[entity2Pos[0]+entity2Pos[2]/2,entity2Pos[1]+entity2Pos[3]]
			];
		case(HORIZONTAL_0):
			return[
				[entity1Pos[0],entity1Pos[1]+entity1Pos[3]/2],
				[(entity1Pos[0]+entity2Pos[0]+entity2Pos[2])/2,entity1Pos[1]+entity1Pos[3]/2],
				[(entity1Pos[0]+entity2Pos[0]+entity2Pos[2])/2,entity2Pos[1]+entity2Pos[3]/2],
				[entity2Pos[0]+entity2Pos[2],entity2Pos[1]+entity2Pos[3]/2],
			];
		case(HORIZONTAL_1):
			return[
				[entity1Pos[0]+entity1Pos[2],entity1Pos[1]+entity1Pos[3]/2],
				[(entity1Pos[0]+entity1Pos[2]+entity2Pos[0])/2,entity1Pos[1]+entity1Pos[3]/2],
				[(entity1Pos[0]+entity1Pos[2]+entity2Pos[0])/2,entity2Pos[1]+entity2Pos[3]/2],
				[entity2Pos[0],entity2Pos[1]+entity2Pos[3]/2],
			];
		default:
			console.log('ERROR_1:连线位置判断错误');
			return [];
	}
	
	return ;
}


//console.log(m3.parameterization(m3.multiply([2,3,1,2,1,1],[7,5,9,6,2,3])))
//console.log(m3.Numericalization('matrix(1,2,4,5,6,7)'));


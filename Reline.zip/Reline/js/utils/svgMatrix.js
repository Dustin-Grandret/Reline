var SVGMATRIX_LENGTH=6;
class SVGMatrix{
	/*
		注意:svg中:
		matrix(a,b,c,d,e,f)=>
		a c e
		b d f
		0 0 1
	*/
	//此处都是以列优先来处理数据
	constructor() {}
	//svg要求的transform参数格式为matrix(a,b,c,d,e,f);
	static parameterization(value){//value为6值数组
		return "matrix("+value.join(',')+")";
	}
	//将"matrix(a,b,c,d,e,f)"转化为[a,b,c,d,e,f]
	static Numericalization(parameter){
		//7:a从第7位开始,最后一位为),slice函数左开右闭,取到倒数第二位
		var tran=parameter.slice(7,parameter.length-1).split(',');
		var value=new Array(SVGMATRIX_LENGTH);
		for (let i =0;i<SVGMATRIX_LENGTH;++i){
			value[i]=parseFloat(tran[i]);
		}
		return value;
	}
	static translate(dx,dy){
		return [1,0,0,1,dx,dy];
	}
	//按照任意点缩放放缩:
	//translate(-centerX*(factor-1),-centerY*(factor-1));
	//scale(factor)
	static scaleCenter(factor,centerX,centerY){
		return this.multiplyMatrixArray([
			this.translate(-centerX*(factor-1),-centerY*(factor-1)),
			this.scaleOrigin(factor);
		]);
	}
	static scaleOrigin(factor){
		return [factor,0,0,factor,0,0];
	}
	static multiplyMatrixArray(matrixArray){
		var rst=this.one();
		for(let i=0;i<matrixArray.length-1;++i){
			rst=this.multiply(matrixArray[i],rst);
		}
		return rst;
	}
	static multiply(m1,m2){
		/*根据svg的矩阵(列优先)推导出的两个矩阵相乘的结果*/
		return [
			m1[0]*m2[0]+m1[2]*m2[1],
			m1[1]*m2[0]+m1[3]*m2[1],
			m1[0]*m2[2]+m1[2]*m2[3],
			m1[1]*m2[2]+m1[3]*m2[3],
			m1[0]*m2[4]+m1[2]*m2[5]+m1[4],
			m1[1]*m2[4]+m1[3]*m2[5]+m1[5]]
	}
	static one(){
		return [1,0,0,1,0,0];
	}
	static assign(m1,m2){
		for(let i=0;i<6;++i){
			m1[i]=m2[i];
		}
	}
}

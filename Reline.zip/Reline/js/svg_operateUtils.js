"use strict"

/**
 * 获取svg的坐标到屏幕上点(参数为0);获取屏幕上点到svg坐标(参数为1)
 * @param {Object} arg
 * @param {SVGElement} arg.svg 
 * @param {SVGPoint} arg.point 
 * @param {toSvg} arg.toSvg [1]当type为False时获取svg坐标到屏幕上点，为True时获取屏幕上点到svg坐标。默认为True
 */
function screenPoint2SvgPoint(arg){
	if(!arg.toSvg){
		return arg.point.matrixTransform(arg.svg.getScreenCTM().inverse());
	}else{
		return arg.point.matrixTransform(arg.svg.getScreenCTM());
	}
}

function viewBoxPara(arg){
	var $viewBox=''
	for(let i=0;i<3;i++){
		$viewBox+=parseInt(arg.viewBox[i])+',';
	}
	$viewBox+=parseInt(arg.viewBox[3]);
	return $viewBox;
}

function initSvg(arg){
	arg.svg.setAttribute('viewBox',viewBoxPara(arg));
	arg.svg.setAttribute('preserveAspectRatio',"xMinYMin meet")
}
/**
 * @description 生成一个SVG元素,默认生成一个无类的标签为g的元素
 * @example
	var arg=createSvgElement({
		tag:'rect',
		class:'rectBasic',
		id:'123',
	})
 * @param {Object} arg -元素所含信息所封装成的对象
 * @param {string} ["http://www.w3.org/2000/svg"] arg.xmlns -元素所使用的xmlns空间
 * @param {string} ["g"] arg.tag
 * @param {String} arg.class 元素所属类
 * @param {string} arg.id 元素的id编号
 * @param {Array} arg.attributes 元素的属性值
 * @param {Array} arg.children 元素的子元素
 * @return {HTMLElement} 生成的HTML元素,不会自动添加到某个元素中
 */
function createSvgElement(arg){
	var tran=document.createElementNS(arg.xmlns||"http://www.w3.org/2000/svg",arg.tag||"g");
	if(arg.class){
		tran.classList.add(arg.class);
	}
	if(arg.id){
		tran.setAttribute('id',arg.id);
	}
	if(arg.attributes){
		Object.keys(arg.attributes).forEach((key)=>{
			tran.setAttribute(key,arg.attributes[key]);
		});
	}
	if(arg.children &&arg.children.length>0){
		arg.children.forEach((elem)=>{tran.appendChild(createSvgElement(elem))});
	}
	return tran;
}
/**
 * @param {Object} arg
 * @description 画一个矩形
 * @example
	var arg={
		svg:你的svg元素
	}
 */
function drawRectangle(arg){
	arg.svg.appendChild(createSvgElement(arg));
}

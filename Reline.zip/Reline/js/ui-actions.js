var pressedId='';
//这个文件负责绑定ui事件,内容应该在html和更新内容的js内完成
function _tabPress(element){
	
	var tabbarElement=element.parentNode;
	var contentContainer=document.getElementById(tabbarElement.getAttribute('target'));
	
	
	document.getElementById(tabbarElement.getAttribute('cur-activate')).setAttribute('class','tab');
	element.setAttribute('class','tab'+'-activate');
	tabbarElement.setAttribute('cur-activate',element.getAttribute('id'));
	
	
	document.getElementById(contentContainer.getAttribute('cur-activate')).setAttribute('class','content');
	
	var targetId=element.getAttribute('target');
	
	document.getElementById(targetId).setAttribute('class','content'+'-activate');
	contentContainer.setAttribute('cur-activate',targetId);
}

//绑定
function tabPress(event){
	_tabPress(this);
}
function stringToBool(str){
	if(typeof str!="string"){
		return str;
	}else{
		return str=="true";
	}
}
function _dropdownBoxTabPress(element){
	var dropdownContent=document.getElementById(element.getAttribute('target'));
	/*
	BUG:点击一个选中另外的
	*/
	var isactivate=stringToBool(dropdownContent.getAttribute('activate'));
	if(!isactivate){
		dropdownContent.setAttribute('activate',true);
		dropdownContent.setAttribute('class','dropdown-content'+'-activate');
	}else{
		dropdownContent.setAttribute('activate',false);
		dropdownContent.setAttribute('class','dropdown-content');		
	}
}
function dropdownBoxTabPress(event){
	_dropdownBoxTabPress(this);
}

function bindUis(){
	$('.tab').mousedown(tabPress);
	$('.tab-activate').mousedown(tabPress);
	$('.dropdown-tab').mousedown(dropdownBoxTabPress);
	$('.dropdown-tab-activate').mousedown(dropdownBoxTabPress);
}